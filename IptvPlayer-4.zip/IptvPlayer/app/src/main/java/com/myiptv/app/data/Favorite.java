package com.myiptv.app.data;

import androidx.room.Entity;
import androidx.room.Index;
import androidx.room.PrimaryKey;

/** A favorite channel, movie or series. Stores a snapshot so it survives playlist refreshes. */
@Entity(tableName = "favorites",
        indices = {@Index(value = {"playlistId", "type", "remoteId"}, unique = true)})
public class Favorite {
    @PrimaryKey(autoGenerate = true)
    public long id;
    public long playlistId;
    /** "live", "movie" or "series" */
    public String type;
    public String remoteId;
    public String name;
    public String icon;
    public String streamUrl;
    public long addedAt;
}

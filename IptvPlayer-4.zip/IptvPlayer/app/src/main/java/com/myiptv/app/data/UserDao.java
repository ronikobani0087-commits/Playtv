package com.myiptv.app.data;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;

import java.util.List;

@Dao
public interface UserDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void putFavorite(Favorite f);

    @Query("DELETE FROM favorites WHERE playlistId = :pid AND type = :type AND remoteId = :rid")
    void removeFavorite(long pid, String type, String rid);

    @Query("SELECT * FROM favorites WHERE playlistId = :pid ORDER BY addedAt DESC LIMIT :limit")
    List<Favorite> favorites(long pid, int limit);

    @Query("SELECT remoteId FROM favorites WHERE playlistId = :pid AND type = :type")
    List<String> favoriteIds(long pid, String type);

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void putHistory(History h);

    @Query("SELECT * FROM history WHERE playlistId = :pid AND type = :type ORDER BY updatedAt DESC LIMIT :limit")
    List<History> recentHistory(long pid, String type, int limit);

    @Query("SELECT * FROM history WHERE playlistId = :pid AND type = :type AND remoteId = :rid LIMIT 1")
    History getHistory(long pid, String type, String rid);

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void putOrder(OrderPref o);

    @Query("SELECT json FROM order_prefs WHERE playlistId = :pid AND scope = :scope LIMIT 1")
    String getOrder(long pid, String scope);

    @Query("DELETE FROM order_prefs WHERE playlistId = :pid AND scope LIKE :pattern")
    void clearOrders(long pid, String pattern);
}

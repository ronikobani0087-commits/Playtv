package com.myiptv.app.ui;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;

import com.myiptv.app.R;
import com.myiptv.app.data.AppDatabase;
import com.myiptv.app.data.Favorite;
import com.myiptv.app.data.History;
import com.myiptv.app.data.Item;
import com.myiptv.app.data.Playlist;
import com.myiptv.app.data.SyncRepository;
import com.myiptv.app.data.UserDao;
import com.myiptv.app.data.UserDatabase;
import com.myiptv.app.util.Async;
import com.myiptv.app.util.EpgRepository;
import com.myiptv.app.util.Prefs;
import com.myiptv.app.util.SportsRepository;
import com.myiptv.app.util.Ui;

import java.text.DateFormat;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class HomeFragment extends Fragment {
    private TextView subtitle;
    private TextView counts;
    private TextView status;
    private TextView action;
    private TextView refresh;
    private LinearLayout footer;
    private CardStrip stripMatches;
    private CardStrip stripFollow;
    private CardStrip stripFav;
    private CardStrip stripRecent;
    private long activeId = -1;
    private int loadToken;

    /** Provider guide entries and beIN channels, used to find a channel for a match. */
    private volatile List<EpgRepository.Match> epgMatches = new ArrayList<>();
    private volatile List<Item> beinList = new ArrayList<>();

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        Context c = requireContext();
        ScrollView scroll = new ScrollView(c);
        scroll.setFillViewport(true);
        scroll.setSmoothScrollingEnabled(true);

        LinearLayout root = new LinearLayout(c);
        root.setOrientation(LinearLayout.VERTICAL);
        int pad = Ui.dp(c, 16);
        root.setPadding(pad, pad, pad, pad);
        scroll.addView(root, new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        status = new TextView(c);
        status.setTextColor(ContextCompat.getColor(c, R.color.muted));
        status.setTextSize(13);
        status.setLineSpacing(0, 1.3f);
        status.setVisibility(View.GONE);
        root.addView(status, lp(c, 0));

        stripMatches = new CardStrip(c, "مباريات اليوم", null);
        stripFollow = new CardStrip(c, "مسلسلات أتابعها", null);
        stripFav = new CardStrip(c, "المفضلة",
                "اضغط على النجمة ☆ بجانب أي قناة أو فيلم أو مسلسل ليظهر هنا.");
        stripRecent = new CardStrip(c, "مسلسلات أُضيفت حديثاً", null);
        root.addView(stripMatches.view, lp(c, 4));
        root.addView(stripFollow.view, lp(c, 18));
        root.addView(stripFav.view, lp(c, 18));
        root.addView(stripRecent.view, lp(c, 18));

        footer = new LinearLayout(c);
        footer.setOrientation(LinearLayout.VERTICAL);
        subtitle = new TextView(c);
        subtitle.setTextColor(ContextCompat.getColor(c, R.color.muted));
        subtitle.setTextSize(12);
        subtitle.setTextDirection(View.TEXT_DIRECTION_ANY_RTL);
        footer.addView(subtitle);
        counts = new TextView(c);
        counts.setTextColor(ContextCompat.getColor(c, R.color.accent));
        counts.setTextSize(12);
        footer.addView(counts, lp(c, 4));

        LinearLayout row = new LinearLayout(c);
        row.setOrientation(LinearLayout.HORIZONTAL);
        action = Ui.button(c, "إضافة قائمة", true);
        row.addView(action);
        refresh = Ui.button(c, "تحديث القائمة", false);
        LinearLayout.LayoutParams fp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        fp.setMarginStart(Ui.dp(c, 10));
        refresh.setOnClickListener(v -> doRefresh());
        refresh.setVisibility(View.GONE);
        row.addView(refresh, fp);
        footer.addView(row, lp(c, 10));
        root.addView(footer, lp(c, 24));
        return scroll;
    }

    private static LinearLayout.LayoutParams lp(Context c, int topDp) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        p.topMargin = Ui.dp(c, topDp);
        return p;
    }

    @Override
    public void onResume() {
        super.onResume();
        load();
    }

    private void load() {
        final Context app = requireContext().getApplicationContext();
        final int token = ++loadToken;
        Async.io(() -> {
            AppDatabase db = AppDatabase.get(app);
            UserDao ud = UserDatabase.get(app).dao();
            long id = Prefs.getActive(app);
            final Playlist p = id < 0 ? null : db.dao().getPlaylist(id);

            int live = 0, movies = 0, series = 0;
            List<Favorite> favs = new ArrayList<>();
            List<History> follow = new ArrayList<>();
            List<Item> recent = new ArrayList<>();
            List<Item> bein = new ArrayList<>();
            if (p != null) {
                live = db.dao().countItems(p.id, "live");
                movies = db.dao().countItems(p.id, "movie");
                series = db.dao().countItems(p.id, "series");
                favs = ud.favorites(p.id, 40);
                follow = ud.recentHistory(p.id, "series", 20);
                recent = db.dao().recentSeries(p.id, 20);
                bein = db.dao().beinChannels(p.id, 24);
            }
            final int fLive = live, fMovies = movies, fSeries = series;
            final List<Favorite> fFavs = favs;
            final List<History> fFollow = follow;
            final List<Item> fRecent = recent;
            final List<Item> fBein = bein;
            beinList = bein;

            Async.main(() -> {
                if (!isAdded() || token != loadToken) return;
                bind(p, fLive, fMovies, fSeries, fFavs, fFollow, fRecent);
            });

            if (p != null) {
                loadMatches(p, fBein, token);
            } else {
                Async.main(() -> {
                    if (isAdded() && token == loadToken) stripMatches.set(new ArrayList<CardStrip.Card>());
                });
            }
        });
    }

    private void bind(@Nullable Playlist p, int live, int movies, int series,
                      List<Favorite> favs, List<History> follow, List<Item> recent) {
        NumberFormat nf = NumberFormat.getInstance();
        final long pid = p == null ? -1 : p.id;
        activeId = pid;
        if (p == null) {
            subtitle.setText("");
            counts.setText("");
            status.setText("لا توجد قائمة مضافة بعد.\nأضف اشتراكك (Xtream أو M3U) لعرض القنوات والأفلام والمسلسلات.");
            status.setVisibility(View.VISIBLE);
        } else {
            String when = p.updatedAt > 0
                    ? "  ·  آخر تحديث: " + DateFormat.getDateTimeInstance(
                    DateFormat.SHORT, DateFormat.SHORT).format(new Date(p.updatedAt))
                    : "";
            subtitle.setText(p.name + when);
            counts.setText(nf.format(live) + " قناة  ·  " + nf.format(movies) + " فيلم  ·  "
                    + nf.format(series) + " مسلسل");
            if (!status.getText().toString().startsWith("تعذر")) {
                status.setText("");
                status.setVisibility(View.GONE);
            }
        }
        refresh.setVisibility(pid < 0 ? View.GONE : View.VISIBLE);
        action.setText(pid < 0 ? "إضافة قائمة" : "إدارة القوائم");
        action.setOnClickListener(v -> {
            MainActivity a = (MainActivity) requireActivity();
            if (activeId < 0) a.openAddPlaylist();
            else a.select(R.id.nav_settings);
        });
        stripFav.setForceHidden(pid < 0);

        // Series I follow
        List<CardStrip.Card> followCards = new ArrayList<>();
        for (final History h : follow) {
            CardStrip.Card c = new CardStrip.Card();
            c.kind = CardStrip.POSTER;
            c.title = nz(h.name);
            c.image = nz(h.icon);
            c.fallback = R.drawable.ic_series;
            c.click = () -> resume(h);
            followCards.add(c);
        }
        stripFollow.set(followCards);

        // Favorites
        List<CardStrip.Card> favCards = new ArrayList<>();
        for (final Favorite f : favs) {
            CardStrip.Card c = new CardStrip.Card();
            c.kind = "live".equals(f.type) ? CardStrip.CHANNEL : CardStrip.POSTER;
            c.title = nz(f.name);
            c.image = nz(f.icon);
            c.fallback = iconFor(f.type);
            c.click = () -> openFavorite(f);
            favCards.add(c);
        }
        stripFav.set(pid < 0 ? new ArrayList<CardStrip.Card>() : favCards);

        // Recently added series
        List<CardStrip.Card> recentCards = new ArrayList<>();
        for (final Item it : recent) {
            CardStrip.Card c = new CardStrip.Card();
            c.kind = CardStrip.POSTER;
            c.title = nz(it.name);
            c.image = nz(it.icon);
            c.rating = nz(it.rating);
            c.fallback = R.drawable.ic_series;
            c.click = () -> {
                if (!isAdded()) return;
                if (it.streamUrl != null && !it.streamUrl.isEmpty()) {
                    PlayerActivity.start(requireContext(), it.streamUrl, it.name);
                } else {
                    SeriesPicker.show(requireActivity(), activeId, it.name, it.remoteId, it.icon);
                }
            };
            recentCards.add(c);
        }
        stripRecent.set(recentCards);
    }

    // ---------------------------------------------------------------- matches

    private void loadMatches(final Playlist p, final List<Item> bein, final int token) {
        new Thread(() -> {
            // 1) matches with logos, scores and minute
            List<SportsRepository.Match> sports = new ArrayList<>();
            try {
                sports = SportsRepository.today();
            } catch (Exception ignored) {
                // fall back below
            }
            if (!sports.isEmpty()) {
                final List<CardStrip.Card> cards = new ArrayList<>();
                for (final SportsRepository.Match m : sports) cards.add(matchCard(m));
                Async.main(() -> {
                    if (!isAdded() || token != loadToken) return;
                    stripMatches.setTitle("مباريات اليوم");
                    stripMatches.set(cards);
                });
            }

            // 2) provider guide: lets a tapped match open the right channel
            List<EpgRepository.Match> epg = new ArrayList<>();
            if ("xtream".equals(p.type) && !bein.isEmpty()) {
                try {
                    epg = EpgRepository.load(p, bein);
                } catch (Exception ignored) {
                    // the channel picker is used instead
                }
            }
            epgMatches = epg;
            if (!sports.isEmpty()) return;

            // 3) no match data: show the guide entries, or the beIN channels
            final List<CardStrip.Card> cards = new ArrayList<>();
            long now = System.currentTimeMillis() / 1000L;
            boolean fallbackChannels = epg.isEmpty();
            if (!fallbackChannels) {
                for (final EpgRepository.Match m : epg) {
                    CardStrip.Card c = new CardStrip.Card();
                    c.kind = CardStrip.TEXT;
                    c.title = m.title;
                    c.subtitle = timeLabel(m.start) + " · " + m.channel;
                    c.badge = (m.start <= now && now < m.stop) ? "● الآن" : "";
                    c.click = () -> play(m.streamUrl, m.title);
                    cards.add(c);
                }
            } else {
                int n = 0;
                for (final Item it : bein) {
                    final int num = ++n;
                    CardStrip.Card c = new CardStrip.Card();
                    c.kind = CardStrip.CHANNEL;
                    c.title = nz(it.name);
                    c.image = nz(it.icon);
                    c.fallback = R.drawable.ic_live;
                    c.click = () -> playLive(it, num);
                    cards.add(c);
                }
            }
            final boolean ch = fallbackChannels;
            Async.main(() -> {
                if (!isAdded() || token != loadToken) return;
                stripMatches.setTitle(ch ? "قنوات بي إن سبورت" : "أهم المباريات");
                stripMatches.set(cards);
            });
        }).start();
    }

    private CardStrip.Card matchCard(final SportsRepository.Match m) {
        CardStrip.Card c = new CardStrip.Card();
        c.kind = CardStrip.MATCH;
        c.league = m.league;
        c.home = m.home;
        c.away = m.away;
        c.homeLogo = m.homeLogo;
        c.awayLogo = m.awayLogo;
        c.live = "in".equals(m.state);
        if ("pre".equals(m.state)) {
            c.score = new SimpleDateFormat("HH:mm", Locale.getDefault()).format(new Date(m.start));
            c.badge = isTomorrow(m.start) ? "غداً" : "";
        } else {
            // left-to-right on screen: away team on the left, home team on the right
            c.score = m.awayScore + " - " + m.homeScore;
            if (c.live) c.badge = ("مباشر " + nz(m.clock)).trim();
            else c.badge = "انتهت";
        }
        c.click = () -> onMatchClick(m);
        return c;
    }

    private static boolean isTomorrow(long ms) {
        Calendar now = Calendar.getInstance();
        Calendar t = Calendar.getInstance();
        t.setTimeInMillis(ms);
        return t.get(Calendar.DAY_OF_YEAR) != now.get(Calendar.DAY_OF_YEAR)
                || t.get(Calendar.YEAR) != now.get(Calendar.YEAR);
    }

    private void onMatchClick(SportsRepository.Match m) {
        if (!isAdded()) return;
        EpgRepository.Match hit = findGuideEntry(m);
        if (hit != null) {
            Item ch = findChannel(hit.streamUrl);
            if (ch != null) playLive(ch, indexOf(ch));
            else play(hit.streamUrl, hit.channel);
            return;
        }
        chooseChannel();
    }

    private EpgRepository.Match findGuideEntry(SportsRepository.Match m) {
        List<EpgRepository.Match> list = epgMatches;
        EpgRepository.Match either = null;
        for (EpgRepository.Match e : list) {
            String t = e.title == null ? "" : e.title.toLowerCase(Locale.ROOT);
            boolean h = containsAny(t, m.homeNames);
            boolean a = containsAny(t, m.awayNames);
            if (h && a) return e;
            if ((h || a) && either == null) either = e;
        }
        return either;
    }

    private static boolean containsAny(String text, List<String> names) {
        for (String n : names) {
            if (text.contains(n.toLowerCase(Locale.ROOT))) return true;
        }
        return false;
    }

    private Item findChannel(String url) {
        if (url == null) return null;
        for (Item it : beinList) {
            if (url.equals(it.streamUrl)) return it;
        }
        return null;
    }

    private int indexOf(Item ch) {
        int i = beinList.indexOf(ch);
        return i < 0 ? 0 : i + 1;
    }

    private void chooseChannel() {
        final List<Item> list = beinList;
        if (list.isEmpty()) {
            Toast.makeText(requireContext(), "لا توجد قناة متاحة لهذه المباراة", Toast.LENGTH_SHORT).show();
            return;
        }
        String[] names = new String[list.size()];
        for (int i = 0; i < names.length; i++) names[i] = nz(list.get(i).name);
        new AlertDialog.Builder(requireContext())
                .setTitle("اختر القناة")
                .setItems(names, (d, which) -> playLive(list.get(which), which + 1))
                .show();
    }

    // ---------------------------------------------------------------- actions

    private void play(String url, String title) {
        if (!isAdded() || url == null || url.isEmpty()) return;
        PlayerActivity.start(requireContext(), url, title);
    }

    private void playLive(Item it, int number) {
        if (!isAdded() || it.streamUrl == null || it.streamUrl.isEmpty()) return;
        PlayerActivity.startLive(requireContext(), it.streamUrl, it.name, it.icon, number, "بث مباشر");
    }

    private void openFavorite(Favorite f) {
        if (!isAdded()) return;
        if ("series".equals(f.type) && (f.streamUrl == null || f.streamUrl.isEmpty())) {
            SeriesPicker.show(requireActivity(), activeId, f.name, f.remoteId, f.icon);
        } else if ("live".equals(f.type) && f.streamUrl != null && !f.streamUrl.isEmpty()) {
            PlayerActivity.startLive(requireContext(), f.streamUrl, f.name, f.icon, 0, "بث مباشر");
        } else {
            play(f.streamUrl, f.name);
        }
    }

    private void resume(History h) {
        if (!isAdded()) return;
        if (h.streamUrl == null || h.streamUrl.isEmpty()) {
            SeriesPicker.show(requireActivity(), activeId, h.name, h.remoteId, h.icon);
            return;
        }
        PlayerActivity.startTracked(requireContext(), h.streamUrl, h.name + " - " + nz(h.episodeTitle),
                h.playlistId, "series", h.remoteId, h.name, h.icon, h.episodeTitle, h.positionMs);
    }

    private static String timeLabel(long startSec) {
        Calendar now = Calendar.getInstance();
        Calendar start = Calendar.getInstance();
        start.setTimeInMillis(startSec * 1000L);
        String hm = new SimpleDateFormat("HH:mm", Locale.getDefault()).format(start.getTime());
        if (start.getTimeInMillis() <= System.currentTimeMillis()) return "بدأت " + hm;
        int dayDiff = start.get(Calendar.DAY_OF_YEAR) - now.get(Calendar.DAY_OF_YEAR);
        if (start.get(Calendar.YEAR) != now.get(Calendar.YEAR)) dayDiff = 2;
        if (dayDiff == 0) return "اليوم " + hm;
        if (dayDiff == 1) return "غداً " + hm;
        return new SimpleDateFormat("d/M HH:mm", Locale.getDefault()).format(start.getTime());
    }

    private static int iconFor(String type) {
        if ("movie".equals(type)) return R.drawable.ic_movie;
        if ("series".equals(type)) return R.drawable.ic_series;
        return R.drawable.ic_live;
    }

    private static String nz(String s) {
        return s == null ? "" : s;
    }

    private void doRefresh() {
        if (activeId < 0) return;
        refresh.setEnabled(false);
        status.setVisibility(View.VISIBLE);
        SyncRepository.sync(requireContext(), activeId, new SyncRepository.Callback() {
            @Override
            public void onProgress(String message) {
                if (isAdded()) status.setText(message);
            }

            @Override
            public void onDone() {
                if (!isAdded()) return;
                refresh.setEnabled(true);
                status.setText("");
                status.setVisibility(View.GONE);
                load();
            }

            @Override
            public void onError(String message) {
                if (!isAdded()) return;
                refresh.setEnabled(true);
                status.setText("تعذر التحديث: " + message);
                status.setVisibility(View.VISIBLE);
            }
        });
    }
}

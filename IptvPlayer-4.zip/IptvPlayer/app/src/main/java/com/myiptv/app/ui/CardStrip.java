package com.myiptv.app.ui;

import android.content.Context;
import android.graphics.Outline;
import android.graphics.Typeface;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewOutlineProvider;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.myiptv.app.R;
import com.myiptv.app.util.Ui;

import java.util.ArrayList;
import java.util.List;

/** A titled horizontal row of cards, used on the home screen. */
public final class CardStrip {
    public static final int POSTER = 0;   // movie / series poster with the title underneath
    public static final int CHANNEL = 1;  // channel logo on a wide tile
    public static final int MATCH = 2;    // football match with team logos and score
    public static final int TEXT = 3;     // text only tile (used when no match data is available)

    public static final class Card {
        public int kind = POSTER;
        public String title = "";
        public String subtitle = "";
        public String badge = "";
        public String image = "";
        public String rating = "";
        public int fallback = R.drawable.ic_movie;
        // match fields
        public String league = "";
        public String home = "";
        public String away = "";
        public String homeLogo = "";
        public String awayLogo = "";
        /** Already ordered left-to-right: "away - home". */
        public String score = "";
        public boolean live;
        public Runnable click;
    }

    public static final int POSTER_W = 96;
    public static final int POSTER_H = 132;
    public static final int CHANNEL_W = 112;
    public static final int CHANNEL_H = 66;
    public static final int MATCH_W = 214;
    public static final int MATCH_H = 100;

    public final LinearLayout view;
    private final TextView heading;
    private final TextView hint;
    private final RecyclerView list;
    private final String emptyHint;
    private final Adapter adapter = new Adapter();
    private boolean forceHidden;

    /** @param emptyHint shown under the title when there are no cards; null hides the whole strip. */
    public CardStrip(Context c, String title, String emptyHint) {
        this.emptyHint = emptyHint;
        view = new LinearLayout(c);
        view.setOrientation(LinearLayout.VERTICAL);
        view.setVisibility(View.GONE);

        heading = new TextView(c);
        heading.setText(title);
        heading.setTextColor(ContextCompat.getColor(c, R.color.text));
        heading.setTextSize(16);
        heading.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        heading.setPadding(Ui.dp(c, 4), 0, Ui.dp(c, 4), 0);
        view.addView(heading);

        hint = new TextView(c);
        hint.setTextColor(ContextCompat.getColor(c, R.color.muted));
        hint.setTextSize(12);
        hint.setText(emptyHint == null ? "" : emptyHint);
        hint.setVisibility(View.GONE);
        LinearLayout.LayoutParams hp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        hp.topMargin = Ui.dp(c, 6);
        view.addView(hint, hp);

        list = new RecyclerView(c);
        list.setLayoutManager(new LinearLayoutManager(c, LinearLayoutManager.HORIZONTAL, false));
        list.setAdapter(adapter);
        list.setClipToPadding(false);
        list.setItemViewCacheSize(8);
        list.setPadding(Ui.dp(c, 2), Ui.dp(c, 4), Ui.dp(c, 2), Ui.dp(c, 4));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.topMargin = Ui.dp(c, 8);
        view.addView(list, lp);
    }

    public void setTitle(String t) {
        heading.setText(t);
    }

    /** Hides the strip completely, even when it has an empty-state hint. */
    public void setForceHidden(boolean hidden) {
        forceHidden = hidden;
        if (hidden) view.setVisibility(View.GONE);
    }

    public void set(List<Card> cards) {
        adapter.data = cards == null ? new ArrayList<Card>() : cards;
        adapter.notifyDataSetChanged();
        boolean empty = adapter.data.isEmpty();
        if (forceHidden || (empty && emptyHint == null)) {
            view.setVisibility(View.GONE);
            return;
        }
        view.setVisibility(View.VISIBLE);
        hint.setVisibility(empty ? View.VISIBLE : View.GONE);
        list.setVisibility(empty ? View.GONE : View.VISIBLE);
    }

    // ------------------------------------------------------------ view helpers

    /** Clips an image view to rounded corners. */
    public static void round(ImageView img, final int radiusPx) {
        img.setClipToOutline(true);
        img.setOutlineProvider(new ViewOutlineProvider() {
            @Override
            public void getOutline(View v, Outline outline) {
                outline.setRoundRect(0, 0, v.getWidth(), v.getHeight(), radiusPx);
            }
        });
    }

    public static void load(ImageView img, String url, int fallback, int w, int h) {
        Context c = img.getContext();
        if (url != null && url.startsWith("http")) {
            Glide.with(c).load(url).override(w, h).placeholder(fallback).error(fallback).into(img);
        } else {
            Glide.with(c).clear(img);
            img.setImageResource(fallback);
        }
    }

    private static final class Adapter extends RecyclerView.Adapter<Adapter.VH> {
        List<Card> data = new ArrayList<>();

        @Override
        public int getItemViewType(int position) {
            return data.get(position).kind;
        }

        @NonNull
        @Override
        public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            Context c = parent.getContext();
            switch (viewType) {
                case MATCH:
                    return buildMatch(c);
                case CHANNEL:
                    return buildChannel(c);
                case TEXT:
                    return buildText(c);
                default:
                    return buildPoster(c);
            }
        }

        private static RecyclerView.LayoutParams itemLp(Context c, int widthDp) {
            RecyclerView.LayoutParams lp = new RecyclerView.LayoutParams(
                    Ui.dp(c, widthDp), ViewGroup.LayoutParams.WRAP_CONTENT);
            lp.setMarginEnd(Ui.dp(c, 10));
            return lp;
        }

        private static TextView text(Context c, int sp, int colorRes) {
            TextView t = new TextView(c);
            t.setTextSize(sp);
            t.setTextColor(ContextCompat.getColor(c, colorRes));
            t.setMaxLines(1);
            t.setEllipsize(TextUtils.TruncateAt.END);
            t.setTextDirection(View.TEXT_DIRECTION_ANY_RTL);
            return t;
        }

        private static VH buildPoster(Context c) {
            LinearLayout root = new LinearLayout(c);
            root.setOrientation(LinearLayout.VERTICAL);
            root.setLayoutParams(itemLp(c, POSTER_W));

            FrameLayout frame = new FrameLayout(c);
            frame.setBackgroundResource(R.drawable.bg_poster);
            frame.setFocusable(true);
            frame.setClickable(true);
            frame.setPadding(Ui.dp(c, 2), Ui.dp(c, 2), Ui.dp(c, 2), Ui.dp(c, 2));
            root.addView(frame, new LinearLayout.LayoutParams(Ui.dp(c, POSTER_W), Ui.dp(c, POSTER_H)));

            ImageView img = new ImageView(c);
            img.setScaleType(ImageView.ScaleType.CENTER_CROP);
            img.setBackgroundColor(ContextCompat.getColor(c, R.color.card2));
            round(img, Ui.dp(c, 10));
            frame.addView(img, new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

            TextView inTitle = text(c, 12, R.color.muted);
            inTitle.setMaxLines(4);
            inTitle.setGravity(Gravity.CENTER);
            inTitle.setPadding(Ui.dp(c, 6), 0, Ui.dp(c, 6), 0);
            frame.addView(inTitle, new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

            TextView rating = text(c, 10, R.color.text);
            rating.setBackgroundResource(R.drawable.bg_badge_dark);
            rating.setPadding(Ui.dp(c, 5), Ui.dp(c, 1), Ui.dp(c, 5), Ui.dp(c, 1));
            FrameLayout.LayoutParams rp = new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                    Gravity.BOTTOM | Gravity.START);
            rp.setMargins(Ui.dp(c, 6), 0, Ui.dp(c, 6), Ui.dp(c, 6));
            frame.addView(rating, rp);

            TextView title = text(c, 12, R.color.text);
            title.setGravity(Gravity.START);
            LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            tp.topMargin = Ui.dp(c, 6);
            root.addView(title, tp);

            VH h = new VH(root, frame);
            h.img = img;
            h.title = title;
            h.inTitle = inTitle;
            h.rating = rating;
            return h;
        }

        private static VH buildChannel(Context c) {
            LinearLayout root = new LinearLayout(c);
            root.setOrientation(LinearLayout.VERTICAL);
            root.setLayoutParams(itemLp(c, CHANNEL_W));

            FrameLayout frame = new FrameLayout(c);
            frame.setBackgroundResource(R.drawable.bg_poster);
            frame.setFocusable(true);
            frame.setClickable(true);
            frame.setPadding(Ui.dp(c, 8), Ui.dp(c, 8), Ui.dp(c, 8), Ui.dp(c, 8));
            root.addView(frame, new LinearLayout.LayoutParams(Ui.dp(c, CHANNEL_W), Ui.dp(c, CHANNEL_H)));

            ImageView img = new ImageView(c);
            img.setScaleType(ImageView.ScaleType.FIT_CENTER);
            frame.addView(img, new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

            TextView title = text(c, 11, R.color.muted);
            title.setGravity(Gravity.START);
            LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            tp.topMargin = Ui.dp(c, 4);
            root.addView(title, tp);

            VH h = new VH(root, frame);
            h.img = img;
            h.title = title;
            return h;
        }

        private static VH buildMatch(Context c) {
            LinearLayout card = new LinearLayout(c);
            card.setOrientation(LinearLayout.VERTICAL);
            card.setFocusable(true);
            card.setClickable(true);
            card.setPadding(Ui.dp(c, 10), Ui.dp(c, 8), Ui.dp(c, 10), Ui.dp(c, 8));
            RecyclerView.LayoutParams lp = new RecyclerView.LayoutParams(
                    Ui.dp(c, MATCH_W), Ui.dp(c, MATCH_H));
            lp.setMarginEnd(Ui.dp(c, 10));
            card.setLayoutParams(lp);

            LinearLayout top = new LinearLayout(c);
            top.setOrientation(LinearLayout.HORIZONTAL);
            top.setGravity(Gravity.CENTER_VERTICAL);
            TextView league = text(c, 11, R.color.muted);
            league.setGravity(Gravity.START);
            top.addView(league, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
            TextView badge = text(c, 10, R.color.muted);
            badge.setPadding(Ui.dp(c, 6), Ui.dp(c, 1), Ui.dp(c, 6), Ui.dp(c, 1));
            top.addView(badge, new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
            card.addView(top, new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

            LinearLayout row = new LinearLayout(c);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);

            LinearLayout homeCol = new LinearLayout(c);
            homeCol.setOrientation(LinearLayout.VERTICAL);
            homeCol.setGravity(Gravity.CENTER_HORIZONTAL);
            ImageView homeLogo = new ImageView(c);
            homeLogo.setScaleType(ImageView.ScaleType.FIT_CENTER);
            homeCol.addView(homeLogo, new LinearLayout.LayoutParams(Ui.dp(c, 34), Ui.dp(c, 34)));
            TextView homeName = text(c, 11, R.color.text);
            homeName.setGravity(Gravity.CENTER);
            homeCol.addView(homeName, new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

            TextView score = text(c, 20, R.color.text);
            score.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
            score.setTextDirection(View.TEXT_DIRECTION_LTR);
            score.setGravity(Gravity.CENTER);
            score.setPadding(Ui.dp(c, 4), 0, Ui.dp(c, 4), 0);

            LinearLayout awayCol = new LinearLayout(c);
            awayCol.setOrientation(LinearLayout.VERTICAL);
            awayCol.setGravity(Gravity.CENTER_HORIZONTAL);
            ImageView awayLogo = new ImageView(c);
            awayLogo.setScaleType(ImageView.ScaleType.FIT_CENTER);
            awayCol.addView(awayLogo, new LinearLayout.LayoutParams(Ui.dp(c, 34), Ui.dp(c, 34)));
            TextView awayName = text(c, 11, R.color.text);
            awayName.setGravity(Gravity.CENTER);
            awayCol.addView(awayName, new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

            // In an RTL layout the first child (home) sits on the right, like the reference app.
            row.addView(homeCol, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
            row.addView(score, new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
            row.addView(awayCol, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
            LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f);
            rp.topMargin = Ui.dp(c, 2);
            card.addView(row, rp);

            VH h = new VH(card, card);
            h.league = league;
            h.badge = badge;
            h.homeLogo = homeLogo;
            h.awayLogo = awayLogo;
            h.homeName = homeName;
            h.awayName = awayName;
            h.score = score;
            return h;
        }

        private static VH buildText(Context c) {
            LinearLayout card = new LinearLayout(c);
            card.setOrientation(LinearLayout.VERTICAL);
            card.setBackgroundResource(R.drawable.bg_match);
            card.setFocusable(true);
            card.setClickable(true);
            card.setPadding(Ui.dp(c, 10), Ui.dp(c, 8), Ui.dp(c, 10), Ui.dp(c, 8));
            RecyclerView.LayoutParams lp = new RecyclerView.LayoutParams(
                    Ui.dp(c, MATCH_W), Ui.dp(c, MATCH_H));
            lp.setMarginEnd(Ui.dp(c, 10));
            card.setLayoutParams(lp);

            TextView badge = text(c, 10, R.color.muted);
            badge.setPadding(Ui.dp(c, 6), Ui.dp(c, 1), Ui.dp(c, 6), Ui.dp(c, 1));
            card.addView(badge, new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
            TextView title = text(c, 13, R.color.text);
            title.setMaxLines(2);
            title.setGravity(Gravity.START);
            LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            tp.topMargin = Ui.dp(c, 6);
            card.addView(title, tp);
            TextView sub = text(c, 11, R.color.muted);
            sub.setGravity(Gravity.START);
            card.addView(sub);

            VH h = new VH(card, card);
            h.badge = badge;
            h.title = title;
            h.sub = sub;
            return h;
        }

        @Override
        public void onBindViewHolder(@NonNull VH h, int position) {
            final Card card = data.get(position);
            Context c = h.itemView.getContext();
            h.click.setOnClickListener(v -> {
                if (card.click != null) card.click.run();
            });
            switch (card.kind) {
                case MATCH: {
                    h.click.setBackgroundResource(card.live ? R.drawable.bg_match_live : R.drawable.bg_match);
                    h.league.setText(card.league);
                    h.homeName.setText(card.home);
                    h.awayName.setText(card.away);
                    h.score.setText(card.score);
                    boolean hasBadge = card.badge != null && !card.badge.isEmpty();
                    h.badge.setVisibility(hasBadge ? View.VISIBLE : View.GONE);
                    h.badge.setText(card.badge);
                    if (card.live) {
                        h.badge.setBackgroundResource(R.drawable.bg_badge_live);
                        h.badge.setTextColor(0xFFFF7A88);
                    } else {
                        h.badge.setBackgroundResource(R.drawable.bg_badge_dark);
                        h.badge.setTextColor(ContextCompat.getColor(c, R.color.muted));
                    }
                    load(h.homeLogo, card.homeLogo, R.drawable.ic_live, 120, 120);
                    load(h.awayLogo, card.awayLogo, R.drawable.ic_live, 120, 120);
                    break;
                }
                case CHANNEL: {
                    h.title.setText(card.title);
                    load(h.img, card.image, card.fallback, 240, 140);
                    break;
                }
                case TEXT: {
                    h.title.setText(card.title);
                    h.sub.setText(card.subtitle);
                    h.sub.setVisibility(card.subtitle == null || card.subtitle.isEmpty() ? View.GONE : View.VISIBLE);
                    boolean hasBadge = card.badge != null && !card.badge.isEmpty();
                    h.badge.setVisibility(hasBadge ? View.VISIBLE : View.GONE);
                    h.badge.setText(card.badge);
                    h.badge.setBackgroundResource(R.drawable.bg_badge_live);
                    h.badge.setTextColor(0xFFFF7A88);
                    break;
                }
                default: {
                    h.title.setText(card.title);
                    boolean hasImg = card.image != null && card.image.startsWith("http");
                    h.inTitle.setText(card.title);
                    h.inTitle.setVisibility(hasImg ? View.GONE : View.VISIBLE);
                    if (hasImg) {
                        load(h.img, card.image, android.R.color.transparent, 300, 420);
                    } else {
                        Glide.with(c).clear(h.img);
                        h.img.setImageDrawable(null);
                    }
                    boolean hasRating = card.rating != null && !card.rating.isEmpty()
                            && !"0".equals(card.rating) && !"0.0".equals(card.rating);
                    h.rating.setVisibility(hasRating ? View.VISIBLE : View.GONE);
                    h.rating.setText(card.rating + " ★");
                    break;
                }
            }
        }

        @Override
        public int getItemCount() {
            return data.size();
        }

        static final class VH extends RecyclerView.ViewHolder {
            final View click;
            ImageView img, homeLogo, awayLogo;
            TextView title, sub, badge, inTitle, rating, league, homeName, awayName, score;

            VH(@NonNull View v, View click) {
                super(v);
                this.click = click;
            }
        }
    }
}
